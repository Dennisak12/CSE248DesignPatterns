package eager_initialization;

//this is an eager initialization
public class Captain {

	// this captain will be created as soon as its loaded into the JVM
	private static Captain _captain = new Captain();

	// prevents other methods from calling this outside of the class
	private Captain() {

	}

	public static Captain makeACaptain() {
		System.out.println("Captain has already been created.");
		return _captain;
	}

}
