package lazy_initialization;
//this is a lazy initialization
public class Captain {

	private static Captain captain;
	
	//prevents other methods from calling this outside of the class
	private Captain(){
		
	}
	
	
	public static Captain makeACaptain(){
		if(captain == null){
			captain = new Captain();
			System.out.println("Okay, you made a captain");
		}else{
			System.out.println("you already have a captain...");
		}
		return captain;
	}
	
}
