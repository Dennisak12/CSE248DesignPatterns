package billPugh;

public class Captain {

	private static Captain captain;
	
	private Captain(){
		
	}
	
	private static class SingletonHelper {
		//returns 1 captain only
		private static final Captain captain = new Captain();
	}
	
	public static Captain makeACaptain(){
		System.out.println("Captain has been returned");
		return SingletonHelper.captain;
	}
	
	
}
