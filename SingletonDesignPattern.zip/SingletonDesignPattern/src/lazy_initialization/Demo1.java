package lazy_initialization;

public class Demo1 {

	public static void main(String[] args) {
		Captain c1 = Captain.makeACaptain();
		System.out.println("Trying to make another captain");
		System.out.println("------------------------------");
		Captain c2 = Captain.makeACaptain();

		// if they are the same, goal is achieved and we share the same
		// attributes
		if (c1 == c2) {
			System.out.println("Are the same instance");
		}
	}

}
